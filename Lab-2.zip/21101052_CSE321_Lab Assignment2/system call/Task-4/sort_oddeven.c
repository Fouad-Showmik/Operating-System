#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

int check(const void *a,const void *b) {
    return (*(int*)b-*(int*)a);
}

void child_process(int numbers[],int num_count) {
    qsort(numbers, num_count, sizeof(int), check);
    printf("Sorted array in descending order: ");
    for (int i = 0; i < num_count; i++) {
        printf("%d ", numbers[i]);
    }
    printf("\n");
    exit(0);
}

int main(int argc,char *argv[]) {
    if (argc<2) {
        printf("Usage: %s <num1> <num2> ...\n", argv[0]);
        return 1;
    }

    int count=argc - 1;
    int num[count];
    pid_t status;
    for (int i = 0; i < count; i++) {
        num[i] = atoi(argv[i + 1]);
    }

    pid_t pid = fork();
    if (pid == 0) {
        child_process(num,count);
    } else {
        wait(&status);
        for (int i=0; i<count; i++) {
            if (num[i] % 2 == 0) {
                printf("%d is even\n", num[i]);
            } else {
                printf("%d is odd\n", num[i]);
            }
        }
    }

    return 0;
}
