#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int check(const void *a, const void *b) {
    return (*(int*)b-*(int*)a);
}

int main(int argc,char*argv[]) {
    if (argc<2) {
        printf("Usage: %s <num1> <num2> ...\n", argv[0]);
        return 1;
    }

    int num_count=argc-1;
    int numbers[num_count];

    for (int i=0;i<num_count;i++) {
        numbers[i]=atoi(argv[i + 1]);
    }

    qsort(numbers,num_count,sizeof(int),check);

    printf("Sorted array in descending order: ");
    for (int i=0;i< num_count;i++) {
        printf("%d ",numbers[i]);
    }
    printf("\n");

    return 0;
}
