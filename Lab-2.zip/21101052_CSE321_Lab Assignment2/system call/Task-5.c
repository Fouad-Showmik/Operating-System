#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid1,pid2,pid3,pid4,status;
    pid1=fork();
    if (pid1 == 0) {
        printf("2. Child process ID: %d\n", getpid());
        pid2 = fork();
        if (pid2 == 0) {
            printf("3. Grand Child process ID: %d\n", getpid());
        } else {
            pid3 = fork();
            if (pid3 == 0) {
                printf("4. Grand Child process ID: %d\n", getpid());
            } else {
                pid4 = fork();
                if (pid4 == 0) {
                    printf("5. Grand Child process ID: %d\n", getpid());
                }
            }
        }
    } else {
        printf("1. Parent process ID: %d\n", getpid());
        for (int i =0;i<4; i++) {
            wait(&status);
}
    }

    return 0;
}
