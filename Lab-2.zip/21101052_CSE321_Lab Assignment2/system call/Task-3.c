#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t a,b,c,status;
    int count=0;

    a=fork();
    if (a==0) {
        if (getpid()% 2!= 0) {
            b = fork();
            if (b == 0) {
            } else {
                wait(&status);
            }
        }
    } else {
        b=fork();
        if (b==0) {
            if (getpid()%2!=0) {
                c=fork();
                if (c==0) {
                } else {
                    wait(&status);
                }
            }
        } else {
            while (wait(&status)>0) {
                count++;
            }
            count++;
            count++; 
            printf("Number of processes created: %d\n",count);
        }
    }
    return 0;
}
