#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int main(int argc,char*argv[]){
    if (argc!= 2) {
        printf("Usage:%s<filename>\n",argv[0]);
        return 1;
    }
    
    char filename[100];
    strcpy(filename,argv[1]);
    int fd = open(filename,O_WRONLY|O_CREAT,0666);
    if (fd ==-1) {
        perror("Error opening file"); 
        printf("Error opening file %s\n",filename);
        return 1;
    }
    
    char input[300];
    printf("Enter a string (enter '-1' to finish):\n");
    while (1) {
        fgets(input,300, stdin);
        input[strcspn(input,"\n")] = 0;

        if (strcmp(input,"-1") == 0) {
            break;
        }

        write(fd,input,strlen(input));
        write(fd,"\n",1);
        printf("Enter a string (enter '-1' to finish):\n");
    }

    close(fd);
    printf("File %s written successfully\n",filename);
    return 0;
}
