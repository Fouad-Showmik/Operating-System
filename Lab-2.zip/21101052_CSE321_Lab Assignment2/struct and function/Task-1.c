#include <stdio.h>

struct Item {
    int quantity;
    float price;
};

int main() {
    struct Item paratha, vegetable, water;
    int people;

    printf("Quantity Of Paratha: ");
    scanf("%d", &paratha.quantity);
    printf("Unit Price: ");
    scanf("%f", &paratha.price);

    printf("Quantity Of Vegetables: ");
    scanf("%d", &vegetable.quantity);
    printf("Unit Price: ");
    scanf("%f", &vegetable.price);

    printf("Quantity Of Mineral Water: ");
    scanf("%d", &water.quantity);
    printf("Unit Price: ");
    scanf("%f", &water.price);


    float bill;
    bill = (paratha.quantity * paratha.price) + (vegetable.quantity * vegetable.price) + (water.quantity * water.price);

    printf("Number of People: ");
    scanf("%d", &people);
    
    float payment;
    payment = bill/people;
    printf("Individual people will pay: %.2f tk\n", payment);

    return 0;
}
