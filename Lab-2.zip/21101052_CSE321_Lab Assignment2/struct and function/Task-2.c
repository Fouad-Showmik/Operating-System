#include <stdio.h>
int perfect(int n){
    int sum=0;
    for (int i=1;i<n;i++) {
        if (n%i==0) {
            sum+=i;
        }
    }
    return (sum==n);
}

void print_numbers(int lower_bound,int upper_bound) {
    for (int i=lower_bound;i<=upper_bound;i++) {
        if (perfect(i)){
            printf("%d\n",i);
        }
    }
}

int main(){
    int lower_bound,upper_bound;
    printf("Enter the lower bound: ");
    scanf("%d",&lower_bound);
    printf("Enter the upper bound: ");
    scanf("%d",&upper_bound);
    printf("Output:\n");
    print_numbers(lower_bound, upper_bound);
    return 0;
}
