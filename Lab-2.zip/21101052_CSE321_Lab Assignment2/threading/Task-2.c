#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
void* thread_function(void* arg) {
    int thread_id = *(int*)arg;
    int start=(thread_id * 5 + 1);
    int end = (start + 4);

    for (int i = start; i <= end; i++) {
        printf("Thread %d prints %d\n", thread_id, i);
        sleep(1); 
    }

    return 0;
}
int main() {
    pthread_t t[5];
    int thread_ids[5];

    for (int i = 0; i < 5; i++) {
        thread_ids[i] = i;
        pthread_create(&t[i], NULL, thread_function, (void*)&thread_ids[i]);
    }

    for (int i = 0; i < 5; i++) {
        pthread_join(t[i], NULL);
    }

    return 0;
}
