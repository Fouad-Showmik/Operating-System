#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

void* thread_function(void* arg) {
    int thread_id = *(int*)arg;
    printf("thread-%d running\n", thread_id);
    sleep(1);
    printf("thread-%d closed\n", thread_id);
    return 0;
}
int main() {
    pthread_t threads[5];
    int thread_ids[5];

    for (int i = 1; i <= 5; i++) {
        thread_ids[i-1] = i;
        pthread_create(&threads[i-1],NULL,thread_function,(void*)&thread_ids[i-1]); 
        pthread_join(threads[i-1], NULL);
    }
    return 0;
}
