#include <pthread.h>
#include <stdio.h>
#include <string.h>

int calc_ascii(const char* name) {
    int count = 0;
    for (int i = 0; i < strlen(name); i++) {
        count += name[i];
    }
    return count;
}

void* thread_function(void* arg) {
    const char* name = (const char*)arg;
    int ascii = calc_ascii(name);
    printf("ASCII Value for %s: %d\n", name, ascii);
    return 0; 
}

int main() {
    pthread_t t[3];
    const char* names[3] = {"Jabed", "Nil", "Shakib"};
    int ascii[3];

    for (int i = 0; i < 3; i++) {
        pthread_create(&t[i], NULL, thread_function, (void*)names[i]);
    }

    for (int i = 0; i < 3; i++) {
        pthread_join(t[i], NULL);
        ascii[i] = calc_ascii(names[i]); 
    }

    if (ascii[0] == ascii[1] && ascii[1] == ascii[2]) {
        printf("Youreka\n");
    } else if (ascii[0] == ascii[1] || ascii[1] == ascii[2] || ascii[0] == ascii[2]) {
        printf("Miracle\n");
    } else {
        printf("Hasta la vista\n");
    }
    return 0;
}
