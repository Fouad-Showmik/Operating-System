#include <stdio.h>

int main(){
    int inp1,inp2,out;
    printf("Enter the first number: ");
    scanf("%d",&inp1);
    
    printf("Enter the second number: ");
    scanf("%d",&inp2);
    
    if (inp1>inp2){
        out=(inp1-inp2);
        printf("The first number is greater than the second number and the subtraction is: %d\n",out);
    }
    else if(inp1<inp2){
        out=(inp1+inp2);
        printf("The first number is less than the second number and the addition is: %d\n",out);
        
    }
    else{
        out=(inp1*inp2);
        printf("The first number is equal to the second number and the multiplication is: %d\n",out);
    }
    return 0;
}
