#include <stdio.h>
#include <string.h>

int main() {
    char input[50];
    char old_domain[] = "@kaaj.com";
    char new_domain[] = "@sheba.xyz";
    
    printf("Enter Your Email: ");
    fgets(input, sizeof(input),stdin);
    input[strcspn(input,"\n")] = '\0';

    char extract[50];
    int j = 0;
    for (int i = 0; i < strlen(input); i++) {
        if (input[i]=='@') {
            while (i < strlen(input)) {
                extract[j++] = input[i++];
            }
            break;
        }
    }
    extract[j] = '\0'; 
    
    if (strcmp(extract,old_domain) == 0) {
        printf("Email address is outdated\n");
    } else if (strcmp(extract,new_domain) == 0) {
        printf("Email address is okay\n");
    } 
    return 0;
}

