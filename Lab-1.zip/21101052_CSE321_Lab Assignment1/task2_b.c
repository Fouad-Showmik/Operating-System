#include <stdio.h>
#include <string.h>
#include <stdbool.h>

int main() {
    FILE *input;
    input = fopen("input.txt", "r");

    FILE *output;
    output = fopen("output.txt", "w");

    if (input == NULL) {
        printf("Error opening the file\n");
        return 1;
    }

    char buffer[1000];
    char final_output[1000] = "";
    bool flag = false;
    int j = 0;

    while (fgets(buffer, sizeof(buffer), input) != NULL) {
        for (int i = 0; i < strlen(buffer); i++) {
            if (buffer[i] != ' ') {
                final_output[j++] = buffer[i];
                flag = true;
            } else if (flag) {
                final_output[j++] = ' ';
                flag = false;
            }
        }
    }
    final_output[j] = '\0';

    fprintf(output,"%s\n",final_output);
    printf("%s\n",final_output);

    fclose(input);
    fclose(output);
    return 0;
}

