#include<stdio.h>
#include<string.h>

int main(){
    char pass[30];
    int digit=0,lower=0,upper=0,special=0;
    char special_character[]="_@$#";
    printf("Enter Your Password: ");
    fgets(pass,sizeof(pass),stdin);
    
    int len=strlen(pass);
    
    for(int i=0;i<len;i++){
        if (pass[i]>='a' && pass[i]<='z'){
            lower+=1;
        }
        if (pass[i]>='A' && pass[i]<='Z'){
            upper+=1;
        }
        if (pass[i]>='0' && pass[i]<='9'){
            digit+=1;
        }
        if (strchr(special_character,pass[i])){
            special+=1;
        }
    }
    if(lower!=0 && upper!=0 && digit!=0 && special!=0){
        printf("OK\n");
    }
    if (lower==0){
        printf("Lowercase character missing\n");
        lower=0;
    }
    if(upper==0){
        printf("Uppercase character missing\n");
        upper=0;
    }
    if(digit==0){
        printf("Digit missing\n");
        digit=0;
    }
    if(special==0){
        printf("Special character missing\n");
        special=0;
    }
    return 0;
}
