#include <stdio.h>
#include<string.h>
#include<stdbool.h>

int main() {
    // Write C code here
    char input[50];
    bool flag=false;
    printf("Enter:");
    scanf("%s",input);
    int length=strlen(input);
    for(int i=0;i<length/2;i++){
        if(input[i]==input[length-1-i]){
            flag=true;
        }
        else{
            flag=false;
        }
    }
    if (flag==true){
        printf("palindrome\n");
    }
    else{
        printf("not palindrome\n");
    }
    return 0;
}
