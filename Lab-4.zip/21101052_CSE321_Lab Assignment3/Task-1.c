#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/wait.h>
struct shared {
    char sel[100];
    int b;
};

int main() {
    int fd[2];
    int fd1[2];

    if (pipe(fd) == -1) {
        perror("pipe_1");
        exit(1);
    }

    if (pipe(fd1) == -1) {
        perror("pipe_2");
        exit(1);
    }

    pid_t pid;
    pid = fork();

    if (pid < 0) {
        perror("fork");
        exit(1);
    }

    if (pid == 0) { 
        close(fd[1]);
        close(fd1[0]);

        int shmid;
        struct shared *shm;

        shmid = shmget((key_t)101, sizeof(struct shared), 0666 | IPC_CREAT);
        shm = shmat(shmid, NULL, 0);

        while (1) {
            read(fd[0], shm, sizeof(struct shared));

            if (strcmp(shm->sel, "a") == 0) {
                int amount;
                printf("Enter amount to be added: ");
                scanf("%d", &amount);

                if (amount > 0) {
                    shm->b += amount;
                    printf("Balance added successfully\n");
                    printf("Updated balance after addition: %d\n", shm->b);
                } else {
                    printf("Adding failed, Invalid amount\n");
                }
            } else if (strcmp(shm->sel, "w") == 0) {
                int amount;
                printf("Enter amount to be withdrawn: ");
                scanf("%d", &amount);

                if (amount > 0 && amount <= shm->b) {
                    shm->b -= amount;
                    printf("Balance withdrawn successfully\n");
                    printf("Updated balance after withdrawal: %d\n", shm->b);
                } else {
                    printf("Withdrawal failed, Invalid amount\n");
                }
            } else if (strcmp(shm->sel, "c") == 0) {
                printf("Your current balance is: %d\n", shm->b);
            } else {
                printf("Invalid selection\n");
            }

            char response[100] = "Thank you for using\n";
            write(fd1[1], response, strlen(response) + 1);
            break;
        }

        shmdt(shm);
        shmctl(shmid, IPC_RMID, NULL);
        close(fd[0]);
        close(fd1[1]);
        exit(0);
    } else { 
        close(fd[0]);
        close(fd1[1]);

        int shmid;
        struct shared *shm;

        shmid = shmget((key_t)101, sizeof(struct shared), 0666 | IPC_CREAT);
        shm = shmat(shmid, NULL, 0);

        printf("Provide Your Input From Given Options:\n");
        printf("1. Type a to Add Money\n");
        printf("2. Type w to Withdraw Money\n");
        printf("3. Type c to Check Balance\n");

        char input[100];
        fgets(input, 100, stdin);
        input[strlen(input) - 1] = '\0'; 

        strcpy(shm->sel, input);
        shm->b = 1000;

        printf("Your selection: %s\n", shm->sel);

        write(fd[1], shm, sizeof(struct shared));

        wait(NULL);

        char buffer[100];
        read(fd1[0], buffer, 100);
        printf("%s", buffer);

        shmdt(shm);
        shmctl(shmid, IPC_RMID, NULL);
        close(fd[1]);
        close(fd1[0]);
        return 0;
    }
}
